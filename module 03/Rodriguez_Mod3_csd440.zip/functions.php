<!--
Carolina Rodriguez
CSD-440
Functions.php for Sum Function
-->

<?php
// Function to add two numbers
function addNumbers($num1, $num2) {
// Return the sum of the two numbers
    return $num1 + $num2;

}
?>
