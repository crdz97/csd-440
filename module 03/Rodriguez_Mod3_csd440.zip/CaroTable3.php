<!--
Carolina Rodriguez
CSD-440
PHP Sum Function Random Number Generation HTML Table

Resources: 

GeeksforGeeks. (2025, July 11). PHP program to generate the random number in the given range (min, max). https://www.geeksforgeeks.org/php/php-program-to-generate-the-random-number-in-the-given-range-min-max/
OpenAI. (2026). ChatGPT [Large language model]. https://chat.openai.com/   
Palik, O. Ş. (2017, April 28). How can I find a set of random numbers that sum to a specific number? [Online forum post]. Stack Overflow.https://stackoverflow.com/questions/43686939/how-can-i-find-a-set-of-random-numbers-that-sum-to-a-specific-number
W3Schools. (n.d.). PHP include files. https://www.w3schools.com/php/php_includes.asp   
    -->


<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Random Number Sum Table</title>
</head>
<body>

<h2>Random Number Sum Table</h2>

<?php //external file for sum function 
include 'functions.php';
?>

<!-- Create table with border and spacing -->
<table border="1" cellpadding="10"> 
    

<?php
//outer loop for rows
for ($row = 1; $row <= 2; $row++) {
?>
    <tr>

    <?php
    // Inner loop for columns
    for ($column = 1; $column <= 2; $column++) {
        //2 random number generation between 1 and 100
        $num1 = rand(1, 100);
        $num2 = rand(1, 100);

        //Sending both numbers to the function to get the sum
        $sum = addNumbers($num1, $num2);
    ?>

        <td> 
        <?php // Display sum of the two random numbers in the table cell
        echo $num1; ?> + 
        <?php 
        echo $num2; ?> = 
        <?php 
        echo $sum; ?>
        
        </td>
<!-- End of inner loop for columns -->
    <?php
    }
    ?>

    </tr>
<!-- End of outer loop for rows -->
<?php
}
?>

</table>

</body>
</html>