<!-- 
 Carolina Rodriguez
 CSD-440
 Assignment 1.3
 Checking Xampp is working with php file

References: 
W3Schools. (n.d.). PHP syntax. https://www.w3schools.com/php/php_syntax.asp

-->

<!DOCTYPE html>
<html>
<head>
    <title>PHP Test</title>
</head>

<body>

<h1>My first PHP page</h1>

<?php
echo 'Hello World!';
?>

<?php
echo "Php is fun!";
?>

</body>
</html>